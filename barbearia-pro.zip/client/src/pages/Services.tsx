import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Scissors } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Services() {
  const { data: services, isLoading } = trpc.services.list.useQuery();

  // Agrupar serviços por categoria
  const servicesByCategory = services?.reduce((acc, service) => {
    const category = service.category || "Outros";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(service);
    return acc;
  }, {} as Record<string, typeof services>);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="border-b border-border">
        <div className="container py-16 md:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-2 text-sm text-primary">
              <Scissors className="h-4 w-4" />
              <span className="font-medium">Serviços Profissionais</span>
            </div>
            <h1 className="mb-6 text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              Nossos Serviços
            </h1>
            <p className="text-lg text-muted-foreground">
              Oferecemos uma ampla variedade de serviços profissionais para cuidar do seu visual com qualidade e estilo.
            </p>
          </div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-16">
        <div className="container">
          {isLoading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="animate-pulse border-border bg-card">
                  <CardHeader>
                    <div className="h-6 w-3/4 rounded bg-muted" />
                    <div className="h-4 w-1/2 rounded bg-muted" />
                  </CardHeader>
                  <CardContent>
                    <div className="mb-2 h-4 w-full rounded bg-muted" />
                    <div className="h-4 w-2/3 rounded bg-muted" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : services && services.length > 0 ? (
            <div className="space-y-12">
              {Object.entries(servicesByCategory || {}).map(([category, categoryServices]) => (
                <div key={category}>
                  <h2 className="mb-6 text-2xl font-bold text-foreground">{category}</h2>
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {categoryServices?.map((service) => (
                      <Card
                        key={service.id}
                        className="border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg"
                      >
                        <CardHeader>
                          <CardTitle className="text-card-foreground">{service.name}</CardTitle>
                          <CardDescription className="text-xl font-bold text-primary">
                            R$ {(service.priceInCents / 100).toFixed(2)}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <p className="text-sm text-muted-foreground">
                            {service.description || "Serviço profissional de alta qualidade"}
                          </p>
                          <div className="flex items-center justify-between border-t border-border pt-4">
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Clock className="mr-2 h-4 w-4" />
                              {service.durationMinutes} min
                            </div>
                            <Button asChild size="sm">
                              <Link href="/agendar">Agendar</Link>
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-lg border border-border bg-card p-12 text-center">
              <Scissors className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 text-xl font-semibold text-foreground">
                Nenhum Serviço Disponível
              </h3>
              <p className="text-muted-foreground">
                Em breve teremos nossos serviços disponíveis para você.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t border-border py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-card p-8 text-center md:p-12">
            <h2 className="mb-4 text-3xl font-bold text-foreground">
              Pronto Para Agendar?
            </h2>
            <p className="mb-8 text-lg text-muted-foreground">
              Escolha o serviço ideal e garanta seu horário com nossos profissionais.
            </p>
            <Button asChild size="lg">
              <Link href="/agendar">Fazer Agendamento</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
