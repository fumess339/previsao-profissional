import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import AdminLink from "@/components/AdminLink";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Scissors, Clock, Star, Calendar, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const { data: services, isLoading: servicesLoading } = trpc.services.list.useQuery();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        <div className="container relative py-24 md:py-32">
          <div className="mx-auto max-w-4xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-2 text-sm text-primary">
              <Scissors className="h-4 w-4" />
              <span className="font-medium">Barbearia Profissional</span>
            </div>
            <h1 className="mb-6 text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
              Estilo e Tradição em
              <span className="block text-primary">Cada Corte</span>
            </h1>
            <p className="mb-8 text-lg text-muted-foreground md:text-xl">
              Agende seu horário online e garanta o melhor atendimento com nossos profissionais especializados.
              Qualidade, conforto e estilo em um só lugar.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Button asChild size="lg" className="group">
                <Link href="/agendar">
                  Agendar Agora
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/servicos">Ver Serviços</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="border-b border-border py-16 md:py-24">
        <div className="container">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
              Por Que Escolher Nossa Barbearia?
            </h2>
            <p className="text-muted-foreground">
              Oferecemos uma experiência completa com profissionais qualificados e ambiente acolhedor.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card className="border-border bg-card transition-all hover:border-primary/50">
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Scissors className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Profissionais Qualificados</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Barbeiros experientes e especializados em cortes clássicos e modernos.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border bg-card transition-all hover:border-primary/50">
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Agendamento Online</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Sistema prático e rápido para marcar seu horário quando quiser.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border bg-card transition-all hover:border-primary/50">
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Horários Flexíveis</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Funcionamento em horários convenientes para atender sua rotina.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border bg-card transition-all hover:border-primary/50">
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Star className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Atendimento Premium</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Ambiente confortável e serviços de alta qualidade para você.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Preview Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">Nossos Serviços</h2>
            <p className="text-muted-foreground">
              Confira nossa variedade de serviços profissionais para cuidar do seu visual.
            </p>
          </div>
          
          {servicesLoading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse border-border bg-card">
                  <CardHeader>
                    <div className="h-6 w-3/4 rounded bg-muted" />
                    <div className="h-4 w-1/2 rounded bg-muted" />
                  </CardHeader>
                  <CardContent>
                    <div className="h-4 w-full rounded bg-muted" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : services && services.length > 0 ? (
            <>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {services.slice(0, 6).map((service) => (
                  <Card key={service.id} className="border-border bg-card transition-all hover:border-primary/50">
                    <CardHeader>
                      <CardTitle className="text-card-foreground">{service.name}</CardTitle>
                      <CardDescription className="text-primary font-semibold">
                        R$ {(service.priceInCents / 100).toFixed(2)}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="mb-4 text-sm text-muted-foreground">
                        {service.description || "Serviço profissional de qualidade"}
                      </p>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="mr-2 h-4 w-4" />
                        {service.durationMinutes} minutos
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="mt-12 text-center">
                <Button asChild size="lg" variant="outline">
                  <Link href="/servicos">Ver Todos os Serviços</Link>
                </Button>
              </div>
            </>
          ) : (
            <div className="rounded-lg border border-border bg-card p-12 text-center">
              <Scissors className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <p className="text-muted-foreground">
                Em breve teremos nossos serviços disponíveis para você.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t border-border py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-3xl rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-card p-8 text-center md:p-12">
            <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
              Pronto Para Transformar Seu Visual?
            </h2>
            <p className="mb-8 text-lg text-muted-foreground">
              Agende agora mesmo e garanta seu horário com os melhores profissionais.
            </p>
            <Button asChild size="lg" className="group">
              <Link href="/agendar">
                Fazer Agendamento
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container">
          <div className="flex flex-col items-center gap-4">
            <AdminLink />
            <p className="text-center text-sm text-muted-foreground">
              © 2025 Base Barbershop. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
