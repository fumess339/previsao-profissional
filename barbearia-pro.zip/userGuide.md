# Guia do Usuário - Base Barbershop

## Informações Gerais

**Propósito:** Sistema completo de agendamento online para barbearia com área administrativa funcional.

**Acesso:** 
- Área pública: Aberta para todos os visitantes
- Área administrativa: Requer login e permissão de administrador

---

## Powered by Manus

**Tecnologias Utilizadas:**

O Base Barbershop foi desenvolvido com tecnologias modernas e robustas para garantir a melhor experiência:

- **Frontend:** React 19 + TypeScript + Tailwind CSS 4 + shadcn/ui (componentes modernos e acessíveis)
- **Backend:** Node.js + Express 4 + tRPC 11 (comunicação type-safe entre cliente e servidor)
- **Banco de Dados:** MySQL/TiDB com Drizzle ORM (queries otimizadas e type-safe)
- **Autenticação:** Manus OAuth (login seguro e gerenciamento de usuários)
- **Deployment:** Auto-scaling infrastructure with global CDN

O sistema oferece performance excepcional, segurança de ponta a ponta e escalabilidade automática para atender qualquer volume de acessos.

---

## Usando Seu Website

### Para Clientes

**Visualizar Serviços:**
Acesse a página inicial e clique em "Ver Serviços" para conhecer todos os serviços oferecidos. Você verá detalhes como preço, duração e descrição de cada serviço organizado por categoria (Corte, Barba, Combo, Tratamentos).

**Fazer um Agendamento:**
1. Clique em "Agendar Agora" na página inicial ou em "Fazer Agendamento" na página de serviços
2. Selecione o barbeiro desejado no menu dropdown
3. Escolha o serviço que deseja realizar
4. Selecione a data e horário disponível
5. Preencha seus dados: nome completo e telefone (obrigatórios), email e observações (opcionais)
6. Clique em "Confirmar Agendamento"
7. Aguarde a mensagem de confirmação

Após o agendamento, você receberá uma confirmação na tela e será redirecionado para a página inicial.

### Para Administradores

**Acessar Área Administrativa:**
Faça login no sistema através do botão "Sign in". Após autenticado, se você tiver permissão de administrador, verá o botão "Área Administrativa" no rodapé da página inicial. Clique nele para acessar o painel.

**Dashboard:**
Visualize estatísticas importantes como agendamentos do dia, total de agendamentos, número de barbeiros e serviços cadastrados. Acompanhe também os agendamentos pendentes e confirmados.

**Gerenciar Barbeiros:**
Acesse "Barbeiros" no menu lateral. Clique em "Adicionar Barbeiro" para cadastrar um novo profissional. Preencha nome (obrigatório), email, telefone, biografia e especialidades. Use os botões "Editar" para modificar informações ou o ícone de lixeira para remover um barbeiro.

**Gerenciar Serviços:**
Acesse "Serviços" no menu lateral. Clique em "Adicionar Serviço" para criar um novo serviço. Preencha nome, categoria, preço, duração e descrição. Os serviços são organizados automaticamente por categoria. Use "Editar" para modificar ou o ícone de lixeira para remover.

**Gerenciar Agendamentos:**
Acesse "Agendamentos" no menu lateral. Visualize todos os agendamentos com informações do cliente, barbeiro, serviço e horário. Use o filtro no topo para ver apenas agendamentos com status específico (Pendentes, Confirmados, Concluídos, Cancelados). Clique em "Confirmar" para aprovar um agendamento pendente, "Concluir" para marcar como finalizado ou "Cancelar" para cancelar.

---

## Gerenciando Seu Website

**Configurações Gerais:**
Abra o Painel de Gerenciamento (ícone no canto superior direito) e vá em "Settings → General" para alterar o nome e logo da barbearia.

**Visualizar Código:**
Acesse o painel "Code" no Painel de Gerenciamento para navegar pelos arquivos do projeto e fazer download se necessário.

**Banco de Dados:**
Use o painel "Database" para visualizar e gerenciar os dados diretamente através de uma interface CRUD. As informações de conexão completas estão disponíveis nas configurações (lembre-se de habilitar SSL).

**Analytics:**
Após publicar o site, acompanhe as métricas de visitantes (UV/PV) através do painel "Dashboard" no Painel de Gerenciamento.

**Domínio Personalizado:**
Acesse "Settings → Domains" para modificar o prefixo do domínio automático (xxx.manus.space) ou vincular seu próprio domínio personalizado.

---

## Próximos Passos

**Personalize sua barbearia:** Converse com o Manus AI a qualquer momento para solicitar alterações, adicionar novas funcionalidades ou ajustar o design do site.

**Comece a receber agendamentos:** Compartilhe o link do seu site com seus clientes e comece a gerenciar seus agendamentos de forma profissional e organizada.

**Publique seu site:** Após configurar tudo, clique no botão "Publish" no Painel de Gerenciamento para tornar seu site público e acessível para todos.
