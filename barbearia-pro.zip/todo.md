# TODO - Barbearia Pro

## Estrutura do Banco de Dados
- [x] Criar tabela de serviços (corte, barba, etc.)
- [x] Criar tabela de barbeiros
- [x] Criar tabela de agendamentos
- [x] Criar tabela de horários disponíveis
- [x] Criar tabela de configurações da barbearia

## Backend - Procedures tRPC
- [x] Procedures para gerenciar serviços (CRUD)
- [x] Procedures para gerenciar barbeiros (CRUD)
- [x] Procedures para gerenciar agendamentos (CRUD)
- [x] Procedures para gerenciar horários disponíveis
- [x] Procedures para dashboard administrativo
- [ ] Procedure para verificar disponibilidade de horários

## Frontend - Área Pública
- [x] Landing page profissional com design moderno
- [x] Página de serviços com galeria
- [x] Sistema de agendamento online para clientes
- [x] Página de confirmação de agendamento
- [x] Visualização de horários disponíveis

## Frontend - Área Administrativa
- [x] Dashboard com estatísticas e métricas
- [x] Gerenciamento de serviços (adicionar, editar, remover)
- [x] Gerenciamento de barbeiros (adicionar, editar, remover)
- [x] Gerenciamento de agendamentos (visualizar, confirmar, cancelar)
- [ ] Gerenciamento de horários de funcionamento
- [ ] Configurações da barbearia (nome, endereço, contato)

## Design e UX
- [x] Definir paleta de cores profissional
- [x] Criar componentes reutilizáveis
- [x] Implementar design responsivo
- [x] Adicionar animações e transições suaves

## Testes e Documentação
- [x] Testar fluxo completo de agendamento
- [x] Testar área administrativa
- [x] Criar guia do usuário
- [x] Salvar checkpoint final

## Dados Iniciais
- [x] Popular banco com barbeiros de exemplo
- [x] Popular banco com serviços de exemplo

## Segurança
- [x] Implementar proteção de rotas administrativas
- [x] Verificar role de admin no backend
- [x] Adicionar link administrativo apenas para admins
